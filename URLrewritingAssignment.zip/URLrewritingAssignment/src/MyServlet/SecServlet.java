package MyServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecServlet
 */
public class SecServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  
          
        //getting value from the query string  
        String n=(request.getParameter("pincode"));  
        out.print(n);
        Map map=new HashMap();  
        boolean isFound1=false;
        //Adding elements to map  
        map.put("123","Delhi");  
        map.put("235","Noida");  
        map.put("322","Mumbai");  
        map.put("346","Greater Noida");
        String city = "";
        if(map.containsKey(n)) {
        	 city= (String)map.get(n);
        	isFound1=true;
        }
        String tech=(String)request.getParameter("technology");
        List<String> jobList = new ArrayList<String>();
        if(tech.equalsIgnoreCase("java") ) // DB
		{
			if(city.equalsIgnoreCase("Delhi")) {
				jobList.add("Project- 1");
				jobList.add("Project- 101");
			}
			if(city.equalsIgnoreCase("Noida")) {
				jobList.add("Project- 11");
				jobList.add("Project- 31");
			}
			if(city.equalsIgnoreCase("Mumbai")) {
				jobList.add("Project- 112");
				jobList.add("Project- 3");
			}
			
		}
		if(tech.equalsIgnoreCase("node.js")) //DB
		{
			jobList.add("Project- 2");
			jobList.add("Project- 201");
			
		}
        
        if(isFound1==true) {
        	out.println("City: "+city);
        	out.println("Jobs "+jobList);
        }
        else {
        	out.print("Wrong Input");
        }
        
	}

	

}
